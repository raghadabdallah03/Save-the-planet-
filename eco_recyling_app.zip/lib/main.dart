import 'package:eco_recyling_app/screens/eco_friendly/start_screen.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      color: Color.fromRGBO(69, 78, 41, 0.004),
      debugShowCheckedModeBanner: false,
      theme: ThemeData(appBarTheme: AppBarTheme()),
      title: 'Onboarding Screen',
      home: StartScreen(),
    );
  }
}
