class Constant{
 static List images=[
  'assets/icons/save_natur.svg',
    'assets/icons/repair-shop-svgrepo-com.svg',
    'assets/icons/earth-waste-svgrepo-com.svg',





 ]; 
}